function Do(i) {
    document.getElementById("DO").play() ;
    document.getElementById("DO").currentTime = 0 ;
}
function Re(i) {
    document.getElementById("RE").play() ;
    document.getElementById("RE").currentTime = 0 ;
}
function Mi(i) {
    document.getElementById("MI").play() ;
    document.getElementById("MI").currentTime = 0 ;
}
function Fa(i) {
    document.getElementById("FA").play() ;
    document.getElementById("FA").currentTime = 0 ;
}
function So(i) {
    document.getElementById("SO").play() ;
    document.getElementById("SO").currentTime = 0 ;
}
function Ra(i) {
    document.getElementById("RA").play() ;
    document.getElementById("RA").currentTime = 0 ;
}
function Si(i) {
    document.getElementById("SI").play() ;
    document.getElementById("SI").currentTime = 0 ;
}
function Do1(i) {
    document.getElementById("DO2").play() ;
    document.getElementById("DO2").currentTime = 0 ;
}